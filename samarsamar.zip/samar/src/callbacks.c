#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "ouvrier.h"
#include "absenteisme.h"

int x=1;
void
on_Gestion_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *GestionOuvriers,*Acceuil;
    GestionOuvriers=lookup_widget(button,"GestionOuvriers");
    Acceuil=lookup_widget(button,"Acceuil");
    gtk_widget_hide(Acceuil);
 GestionOuvriers = create_GestionOuvriers();
 gtk_widget_show(GestionOuvriers);
}

/*********************************************************************************************************************************************/

void
on_samarretour1_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Acceuil,*GestionOuvriers;
 Acceuil=lookup_widget(button,"Acceuil");
 GestionOuvriers=lookup_widget(button,"GestionOuvriers");
 gtk_widget_hide(Acceuil);
 Acceuil = create_Acceuil();
 gtk_widget_show(Acceuil);
}
/*********************************************************************************************************************************************/
void
on_logout1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *GestionOuvriers;
 GestionOuvriers=lookup_widget(button,"GestionOuvriers");
 gtk_widget_hide(GestionOuvriers);
}
/*********************************************************************************************************************************************/

void
on_ModifierOuvrier_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *GestionOuvriers,*ModifierOuvrier;
 GestionOuvriers=lookup_widget(button,"GestionOuvriers");
 ModifierOuvrier=lookup_widget(button,"ModifierOuvrier");
 gtk_widget_hide(GestionOuvriers);
 ModifierOuvrier = create_ModifierOuvrier();
 gtk_widget_show(ModifierOuvrier);
}

/*********************************************************************************************************************************************/
void
on_AjouterOuvrier_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *GestionOuvriers,*AjouterOuvrier;
GestionOuvriers=lookup_widget(button,"GestionOuvriers");
AjouterOuvrier=lookup_widget(button,"AjouterOuvrier");
gtk_widget_hide(GestionOuvriers);
AjouterOuvrier=create_AjouterOuvrier();
gtk_widget_show(AjouterOuvrier);
}

/*********************************************************************************************************************************************/
void
on_RechercherOuvrier_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *GestionOuvriers,*entrycinouvrier,*treeviewrech,*outputMsg,*inexistantt,*res,*msgsupp;
   int verif;
   char ch[9];  
GestionOuvriers=lookup_widget(button,"GestionOuvriers");
entrycinouvrier=lookup_widget(button,"entrycinouvrier");
treeviewrech=lookup_widget(button,"treeviewrech");
inexistantt=lookup_widget(button,"labelb29");
msgsupp=lookup_widget(button,"msgsupp");
//res=lookup_widget(button,"res");
strcpy(ch,gtk_entry_get_text(GTK_ENTRY(entrycinouvrier)));
verif=exist_ouvrier(ch);
switch(verif)   
{
    case 0:  
    {  // gtk_widget_hide (res);
	gtk_widget_hide (msgsupp);
	gtk_widget_show (inexistantt);

    }
    break;
    case 1:
   
    {  rechercher_ouvrier(treeviewrech, ch);
       remove(treeviewrech);
	gtk_widget_hide (inexistantt);
	gtk_widget_hide (msgsupp);
	//gtk_widget_show (res);
       
      }
    break; 
    break;}
}


/*********************************************************************************************************************************************/
void
on_samarretour2_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *AjouterOuvrier,*GestionOuvriers;
 AjouterOuvrier=lookup_widget(button,"AjouterOuvrier");
 GestionOuvriers=lookup_widget(button,"GestionOuvriers");
 gtk_widget_hide(AjouterOuvrier);
 GestionOuvriers = create_GestionOuvriers();
 gtk_widget_show(GestionOuvriers);
}
/*********************************************************************************************************************************************/

void
on_logout2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *AjouterOuvrier;
 AjouterOuvrier=lookup_widget(button,"AjouterOuvrier");

 gtk_widget_hide(AjouterOuvrier);
}

/*********************************************************************************************************************************************/
void
on_logout3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ModifierOuvrier;
 ModifierOuvrier=lookup_widget(button,"ModifierOuvrier");
 gtk_widget_hide(ModifierOuvrier);
}

/*********************************************************************************************************************************************/
void
on_samarretour3_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ModifierOuvrier,*GestionOuvriers;
 ModifierOuvrier=lookup_widget(button,"ModifierOuvrier");
 GestionOuvriers=lookup_widget(button,"GestionOuvriers");
 gtk_widget_hide(ModifierOuvrier);
 GestionOuvriers = create_GestionOuvriers();
 gtk_widget_show(GestionOuvriers);
}



/*********************************************************************************************************************************************/
void
on_Refresh_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
system("make; sudo make install");
GtkWidget *treeviewrech;
treeviewrech=lookup_widget(button,"treeviewrech");
afficher_ouvrier(treeviewrech);
}
/*********************************************************************************************************************************************/

void
on_AjouterOuvrier1_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

infoouvrier o;
Date naissance;
GSList *List;
GtkWidget *AjouterOuvrier;
GtkWidget *entryCin,*entryNom,*entryPrenom,*entryadr,*entryNumtel,*entrynumabs;
GtkWidget *jour,*mois,*annee,*spinbuttonnbre;
GtkWidget *labelCin,*labelnom,*labelprenom,*labeladr,*labelnumtel,*labelnumabs;
GtkWidget *existe,* success;
GtkWidget *radiobutton_homme,*radiobutton_femme;
char sexe[10];
int b=1;
	radiobutton_homme=lookup_widget(button,"radiobutton1");
	radiobutton_femme=lookup_widget(button,"radiobutton2");
	List= gtk_radio_button_get_group (GTK_RADIO_BUTTON (radiobutton_homme));
	if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(List->data)))
	strcpy(sexe,gtk_button_get_label(GTK_BUTTON(List->data)));	
	else{
		List = g_slist_next(List);
		strcpy(sexe,gtk_button_get_label(GTK_BUTTON(List->data)));}
AjouterOuvrier=lookup_widget(button,"AjouterOuvrier");
entryCin=lookup_widget(button,"samarentry7");
entryNom=lookup_widget(button,"samarentry8");
entryPrenom=lookup_widget(button,"samarentry9");
jour=lookup_widget(button,"samarspinbutton1");
mois=lookup_widget(button,"samarspinbutton2");
annee=lookup_widget(button,"samarspinbutton3");
entryadr=lookup_widget(button,"samarentry11");
entryNumtel=lookup_widget(button,"samarentry12");
entrynumabs=lookup_widget(button,"entrynumabs");
spinbuttonnbre=lookup_widget(button,"spinbuttonnbre");

labelCin=lookup_widget(button,"samarlabel1");
labelnom=lookup_widget(button,"samarlabel2");
labelprenom=lookup_widget(button,"samarlabel3");
labeladr=lookup_widget(button,"samarlabel4");
labelnumtel=lookup_widget(button,"samarlabel5");
labelnumabs=lookup_widget(button,"samarlabel6");


existe=lookup_widget(button,"samarlabelexist");
success=lookup_widget(button,"samarlabelsuccess");
        strcpy(o.cin,gtk_entry_get_text(GTK_ENTRY(entryCin) ) );
        strcpy(o.nom,gtk_entry_get_text(GTK_ENTRY(entryNom) ) );
        strcpy(o.prenom,gtk_entry_get_text(GTK_ENTRY(entryPrenom) ) );
	strcpy(o.sexe,sexe);
	o.naissance.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(jour));
	o.naissance.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(mois));
	o.naissance.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(annee));
        strcpy(o.adr,gtk_entry_get_text(GTK_ENTRY(entryadr) ) );
        strcpy(o.numtel,gtk_entry_get_text(GTK_ENTRY(entryNumtel) ) );
	o.nbre_abs=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(spinbuttonnbre));
gtk_widget_hide (success);
gtk_widget_hide (existe);
// controle saisie
if(strcmp(o.cin,"")==0){
		  gtk_widget_show (labelCin);
		  b=0;
}
else {
		  gtk_widget_hide(labelCin);
}

if(strcmp(o.nom,"")==0){
		  gtk_widget_show (labelnom);
		  b=0;
}
else {
		  gtk_widget_hide(labelnom);
}
if(strcmp(o.prenom,"")==0){
		  gtk_widget_show (labelprenom);
		  b=0;
}
else {
		  gtk_widget_hide(labelprenom);
}
if(strcmp(o.adr,"")==0){
		  gtk_widget_show (labeladr);
		  b=0;
}
else {
		  gtk_widget_hide(labeladr);
}
if(strcmp(o.numtel,"")==0){
		  gtk_widget_show (labelnumtel);
		  b=0;
}
else {
		  gtk_widget_hide(labelnumtel);
}



if(b==1){
	 

        if(exist_ouvrier(o.cin)==1)
        {

				  gtk_widget_show (existe);
				  
        }
        else {
						  gtk_widget_hide (existe);
                ajouter_ouvrier(o);
		

						  gtk_widget_show (success);
        }

}
}
/*********************************************************************************************************************************************/

void
on_AfficherOuvrier_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *GestionOuvriers,*treeviewrech;
infoouvrier o;
GestionOuvriers=lookup_widget(button,"GestionOuvriers");
treeviewrech=lookup_widget(GestionOuvriers,"treeviewrech");
afficher_ouvrier(treeviewrech);
}

/*********************************************************************************************************************************************/
void
on_ModifierOuvrier1_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *ModifierOuvrier;
GSList *List;
GtkWidget *entryCin,*entryNom,*entryPrenom,*entryadr,*entryNumtel;
GtkWidget *jour,*mois,*annee,*nbr;
GtkWidget *labelCin,*labelnom,*labelprenom,*labeladr,*labelnumtel;
GtkWidget *succeed,*inexist;
GtkWidget *radiobutton_homme,*radiobutton_femme;
infoouvrier o;
char sexe[10];
int b=1;
	radiobutton_homme=lookup_widget(button,"radiobutton3");
	radiobutton_femme=lookup_widget(button,"radiobutton4");
	List= gtk_radio_button_get_group (GTK_RADIO_BUTTON (radiobutton_homme));
	if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(List->data)))
	strcpy(sexe,gtk_button_get_label(GTK_BUTTON(List->data)));	
	else{
		List = g_slist_next(List);
		strcpy(sexe,gtk_button_get_label(GTK_BUTTON(List->data)));}
ModifierOuvrier=lookup_widget(button,"ModifierOuvrier");
entryCin=lookup_widget(button,"entrymodifcin");
entryNom=lookup_widget(button,"entrymodifnom");
entryPrenom=lookup_widget(button,"entrymodifprenom");
jour=lookup_widget(button,"spinbutton4");
mois=lookup_widget(button,"spinbutton5");
annee=lookup_widget(button,"spinbutton6");
entryadr=lookup_widget(button,"entrymodifadresse");
entryNumtel=lookup_widget(button,"entrymodifnumtel");
nbr=lookup_widget(button,"spinbutton7");

labelCin=lookup_widget(button,"samarlabel77");
labelnom=lookup_widget(button,"samarlabel877");
labelprenom=lookup_widget(button,"samarlabel79");
labeladr=lookup_widget(button,"samarlabel81");
labelnumtel=lookup_widget(button,"samarlabel83");
succeed=lookup_widget(button,"modifsucceed");
inexist=lookup_widget(button,"cininexist");
	strcpy(o.cin,gtk_entry_get_text(GTK_ENTRY(entryCin) ) );
        strcpy(o.nom,gtk_entry_get_text(GTK_ENTRY(entryNom) ) );
        strcpy(o.prenom,gtk_entry_get_text(GTK_ENTRY(entryPrenom) ) );
	strcpy(o.sexe,sexe);
	o.naissance.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(jour));
	o.naissance.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(mois));
	o.naissance.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(annee));
        strcpy(o.adr,gtk_entry_get_text(GTK_ENTRY(entryadr) ) );
        strcpy(o.numtel,gtk_entry_get_text(GTK_ENTRY(entryNumtel) ) );
	o.nbre_abs=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(nbr));
gtk_widget_hide (succeed);
gtk_widget_hide (inexist);
// controle saisie
if(strcmp(o.cin,"")==0){
		  gtk_widget_show (labelCin);
		  b=0;
}
else {
		  gtk_widget_hide(labelCin);
}

if(strcmp(o.nom,"")==0){
		  gtk_widget_show (labelnom);
		  b=0;
}
else {
		  gtk_widget_hide(labelnom);
}
if(strcmp(o.prenom,"")==0){
		  gtk_widget_show (labelprenom);
		  b=0;
}
else {
		  gtk_widget_hide(labelprenom);
}
if(strcmp(o.adr,"")==0){
		  gtk_widget_show (labeladr);
		  b=0;
}
else {
		  gtk_widget_hide(labeladr);
}
if(strcmp(o.numtel,"")==0){
		  gtk_widget_show (labelnumtel);
		  b=0;
}
else {
		  gtk_widget_hide(labelnumtel);
}

if(b==1){
        if(exist_ouvrier(o.cin)==1)
        {
				  modifier_ouvrier(o);
				  gtk_widget_show (succeed);
				  
        }
        else {
						  gtk_widget_hide (succeed);
						  gtk_widget_show (inexist);
                
        }

}
}


/*********************************************************************************************************************************************/

void
on_SupprimerOuvrier_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *entrycinouvrier,*inexistantt,*msgsupp,*label,*res;
infoouvrier o;
char cin[9];
entrycinouvrier=lookup_widget(button,"entrycinouvrier");
//inexistantt=lookup_widget(button,"labelb29");
//label=lookup_widget(button,"label50cin");
//res=lookup_widget(button,"res");
//msgsupp=lookup_widget(button,"msgsupp");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(entrycinouvrier)));




	//if(exist_ouvrier(cin)==1)
      //  {			
				
				supprimer_ouvrier(cin);
				 // gtk_widget_hide (inexistantt);
				  //gtk_widget_hide (label);
				  //gtk_widget_show (msgsupp);
				  //gtk_widget_hide (res);
				  

				  
      //  }
	/*else if(strcmp(o.cin,"")==0){gtk_widget_hide (inexistantt);
					gtk_widget_hide (msgsupp);
					gtk_widget_show (label);}
	else { // gtk_widget_hide (res);
		gtk_widget_hide (label);
		gtk_widget_hide (msgsupp);
		gtk_widget_show (inexistantt);}
*/

}
/*********************************************************************************************************************************************/

void
on_Absenteisme_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *GestionOuvriers,*AjouterAbsence;
    GestionOuvriers=lookup_widget(button,"GestionOuvriers");
    AjouterAbsence=lookup_widget(button,"AjouterAbsence");
    gtk_widget_hide(GestionOuvriers);
 AjouterAbsence = create_AjouterAbsence();
 gtk_widget_show(AjouterAbsence);
}

/*********************************************************************************************************************************************/
void
on_samradiobutton6_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){x=0;}
}

/*********************************************************************************************************************************************/
void
on_samradiobutton5_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){x=1;}
}

/*********************************************************************************************************************************************/
void
on_Enregistrer_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{GSList *List;
GtkWidget *AjouterAbsence,*AfficherAbsence,*entrycinabss;
GtkWidget *scomboboxentry1,*scomboboxentry2,*scomboboxentry3;
ouvrier o;
entrycinabss=lookup_widget(button,"entrycinabss");
strcpy(o.cin,gtk_entry_get_text(GTK_ENTRY(entrycinabss)));
scomboboxentry1=lookup_widget(button,"scomboboxentry1");
scomboboxentry2=lookup_widget(button,"scomboboxentry2");
scomboboxentry3=lookup_widget(button,"scomboboxentry3");

gchar *jour=gtk_combo_box_get_active_text(scomboboxentry1);
gchar *mois=gtk_combo_box_get_active_text(scomboboxentry2);
gchar *annee=gtk_combo_box_get_active_text(scomboboxentry3);
strcpy(o.Absence.jour,jour);
strcpy(o.Absence.mois,mois);
strcpy(o.Absence.annee,annee);

if(x==1)
{o.present=1;}

else 
{o.present=0;}
enregristrer_absence (o);

}

/*********************************************************************************************************************************************/
void
on_AfficherAbs_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *AjouterAbsence,*AfficherAbsence,*treeviewabs;
AjouterAbsence=lookup_widget(button,"AjouterAbsence");
gtk_widget_hide(AjouterAbsence);
AfficherAbsence = create_AfficherAbsence();
gtk_widget_show (AfficherAbsence);
treeviewabs=lookup_widget(AfficherAbsence,"treeviewabs");
afficher_absence(treeviewabs);
}
/*********************************************************************************************************************************************/

void
on_treeviewabs_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* cin;
	gchar* jour;
	gchar* mois;
	gchar* annee;
	gchar* present;	

	ouvrier o;
	
GtkTreeModel *model = gtk_tree_view_get_model(treeview);

if(gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&cin,1,&jour,2,&mois,3,&annee,4,&present, -1);
strcpy(o.cin,cin);
strcpy(o.Absence.jour,jour);
strcpy(o.Absence.mois,mois);
strcpy(o.Absence.annee,annee);
strcpy(o.present,present);
supprimer_absence(o);
afficher_absence(treeview);
}
}


void
on_Taux0_clicked                       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *AjouterAbsence,*Taux;
 AjouterAbsence=lookup_widget(button,"AjouterAbsence");
 Taux=lookup_widget(button,"Taux");
 gtk_widget_hide(AjouterAbsence);
 Taux = create_Taux();
 gtk_widget_show(Taux);
}


void
on_Tauxabs_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *sortiem;
GtkWidget *ta;
GtkWidget *pourcent ;
GtkWidget *comboboxentry1;
GtkWidget *comboboxentry2;

ouvrier o;
int tauxpresence=0;
char tauxtxt[200];
double absence;
double i=0;
float tauxabsence;
FILE *f=NULL;
comboboxentry1=lookup_widget(button,"comboboxentry1");
comboboxentry2=lookup_widget(button,"comboboxentry2");

gchar *mois=gtk_combo_box_get_active_text(comboboxentry1);
gchar *annee=gtk_combo_box_get_active_text(comboboxentry2);

sortiem=lookup_widget(button, "1label");
ta=lookup_widget(button, "2label");
pourcent=lookup_widget(button, "3label");

    f=fopen("absences.txt","r");
    if(f!=NULL)
    {
        while((fscanf(f, "%s %s %s %s %d",o.cin,o.Absence.jour,o.Absence.mois,o.Absence.annee,&o.present)!=EOF))

{
if((strcmp(o.Absence.mois,mois)==0)&&(strcmp(o.Absence.annee,annee)==0))

{
i++;
tauxpresence=tauxpresence+o.present;
}
}
fclose(f);
}
absence=i-tauxpresence;
tauxabsence=(absence/i)*100;

sprintf(tauxtxt,"%.2f",tauxabsence);
gtk_label_set_text(GTK_LABEL(ta),"Le taux d`absence est :");
gtk_label_set_text(GTK_LABEL(pourcent),"%");
gtk_label_set_text(GTK_LABEL(sortiem),tauxtxt);

return 0;
}

