#include <gtk/gtk.h>

typedef struct{

char annee[7];
char mois[5];
char jour[5];
}DATE;


typedef struct
{
char cin[9];
DATE Absence;
int present;

}ouvrier;



void enregristrer_absence (ouvrier o);
void modifier_absence(ouvrier o);
void afficher_absence(GtkWidget *liste);
void supprimer_absence(ouvrier o);
void rechercher_absence(GtkWidget *liste, char ch[]);
int verifier_cinabs(char CIN[]);
int exist_abs(char*cin);
