#include <gtk/gtk.h>

typedef struct {
int jour;
int mois;
int annee;
} Date;

typedef struct { 
char cin[9];
char nom[20];
char prenom [20];
char sexe[10];
Date naissance;
char adr[100];
char numtel[9];
int nbre_abs;
} infoouvrier;



int verifier_cin(char CIN[]);
int exist_ouvrier(char*cin);
void ajouter_ouvrier( infoouvrier o );
void modifier_ouvrier(infoouvrier o);
void supprimer_ouvrier(char cin[]);
void afficher_ouvrier(GtkWidget *liste);
void rechercher_ouvrier(GtkWidget *liste, char ch[]);
void meilleur_ouv(infoouvrier tab_ouv[],int n,char nomFichier[],int annee,char cin[]);
int nbre_total_abs(infoouvrier tab_ouv[],int n,int annee,char nomFichier[]);
int charger_liste(infoouvrier tab_ouv[],int n);

