#include <gtk/gtk.h>


void
on_Gestion_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_samarretour1_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_ModifierOuvrier_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_AjouterOuvrier_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_RechercherOuvrier_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_samarretour2_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_logout2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_logout3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_samarretour3_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_logout1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_Refresh_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_AjouterOuvrier1_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_AfficherOuvrier_activate            (GtkButton       *button,
                                        gpointer         user_data);

void
on_AfficherOuvrier_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_ModifierOuvrier1_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_SupprimerOuvrier_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_Absenteisme_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_samradiobutton6_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_samradiobutton5_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Enregistrer_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_AfficherAbs_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeviewabs_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Taux0_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_Taux_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Tauxabs_clicked                     (GtkButton       *button,
                                        gpointer         user_data);
